# Licences

Original code in this package is available under the MIT License in `LICENSE_CODE.txt`.

Author-created documentation may be reused with attribution. Intermediate data tables may be released under CC BY 4.0 only where the authors have the necessary rights to license the derived content. This package does not relicense NGO Shipbreaking Platform materials, Clarksons Research data, ITF classifications, EU institutional data, or any other third-party source.

The source-specific restrictions and publication checks in `THIRD_PARTY_DATA_NOTICE.md` take precedence over a general repository-level licence label.
