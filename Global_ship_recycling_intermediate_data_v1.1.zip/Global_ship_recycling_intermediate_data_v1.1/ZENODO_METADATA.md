# Zenodo metadata for version 1.1.0

**Upload type:** Dataset

**Title:** Intermediate data for “Global ship recycling separates economic control, legal registration and environmental burdens”

**Version:** 1.1.0

**DOI:** Insert the DOI already reserved or published for this record.

**Creators:** Unknown

**Description:**

This release contains non-record-level intermediate tables used to inspect or recreate manuscript figures on global ship recycling, beneficial ownership, flag registration, and environmental burden transfer. Tables are aggregated by year, country, flag jurisdiction, or manuscript category. The release excludes annual source workbooks, vessel names and identifiers, the vessel-level dismantling analysis file, the licensed active-fleet register, and proprietary market series. Some aggregate tables are derived from licensed fleet data and are included only subject to confirmation of redistribution rights.

**Keywords:** ship recycling; shipbreaking; beneficial ownership; flag state; flags of convenience; Hong Kong Convention; EU Ship Recycling Regulation; environmental justice; maritime governance

**Language:** English

**Access right:** Use open access only after the release checklist and source-licence review are complete.

**Licence:** Mixed. MIT for original code; data licensing is subject to `LICENSES.md` and third-party source terms.

**Related identifier:** Add the article DOI after publication using relation `IsSupplementTo`.
