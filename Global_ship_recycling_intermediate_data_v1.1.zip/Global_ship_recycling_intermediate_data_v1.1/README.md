# Intermediate data for global ship recycling analysis

Version 1.1.0

This release supplements the study **“Global ship recycling separates economic control, legal registration and environmental burdens.”** It contains non-record-level intermediate tables used to inspect or recreate manuscript figures. It does not contain the original annual ship lists, licensed active-fleet files, vessel-level processed data, or proprietary market series.

## Included data

- `data/intermediate/figure1/`: annual retirement-pressure and backlog series.
- `data/intermediate/figure2/`: country- and flag-level pre/post aggregates used for the policy-period figure.
- `data/intermediate/figure3/`: flag-jurisdiction aggregates and governance classifications used for the governance map.
- `data/intermediate/discussion/`: three regional shares used for the responsibility-allocation visualization.
- `DATA_DICTIONARY.md`: file-level definitions, units, sources, and disclosure notes.

All included data are aggregated by year, country, flag jurisdiction, or manuscript category. No row represents an individual vessel.

## Explicit exclusions

The release excludes vessel names, IMO numbers, call signs, MMSI numbers, record-level ages or tonnages, annual source workbooks, the 7,919-row dismantling analysis file, and the licensed Clarksons active-fleet roster. The exclusion list is also enforced by `.gitignore` and checked by `code/01_validate_intermediate_release.py`.

## Validation

From the repository root, run:

```bash
python code/01_validate_intermediate_release.py
```

The validator checks the expected files, aggregation sizes, direct-identifier column names, and manifest checksums. It does not establish redistribution rights.

## Restricted-source boundary

Figure 1 and parts of Figure 3 were derived from a licensed active-fleet source. They are aggregate outputs rather than vessel-level source data, but the right to redistribute derived aggregates must still be confirmed under the applicable licence before making the repository public. See `THIRD_PARTY_DATA_NOTICE.md` and `RELEASE_CHECKLIST.md`.

## Citation and DOI

This folder is prepared as an update to an existing GitHub/Zenodo record. Replace the DOI and repository placeholders in `CITATION.cff` and `ZENODO_METADATA.md` with the identifiers already reserved for the record, then publish a new GitHub release such as `v1.1.0`. Do not create a separate concept DOI if this is intended as a new version of the existing deposit.

## Licence

Original code is released under the MIT License in `LICENSE_CODE.txt`. Data tables may be licensed only to the extent that the authors own the relevant rights. Third-party source terms remain controlling.
