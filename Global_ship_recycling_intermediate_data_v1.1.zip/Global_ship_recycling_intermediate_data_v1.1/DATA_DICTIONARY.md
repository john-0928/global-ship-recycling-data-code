# Intermediate data dictionary

## General conventions

- `pre` denotes 2014–2018 and `post` denotes 2019–2025 unless a file states otherwise.
- Shares without a `_pct` suffix are proportions on a 0–1 scale.
- Fields ending in `_pct` or `_pp` are percentages or percentage-point changes.
- `n_pre` and `n_post` are aggregated vessel counts, not record identifiers.
- `LDT` is light displacement tonnage and `GT` is gross tonnage.

## Figure 1

`figure1_retirement_pressure.xlsx` contains annual values for 2014–2025. `Inflow_20` is the number of active ships crossing the 20-year age threshold; `Annual_Scrapping` is the annual dismantling count; `Gap_20` is inflow minus dismantling; and `Backlog_20` and `Backlog_25` are cumulative non-negative backlog proxies under 20- and 25-year thresholds. The workbook contains only annual aggregates.

## Figure 2

`panelA_dismantling_map_LDT_weighted.csv` contains country-level LDT-weighted dismantling shares and changes. `ldt_post` is an aggregate country total for the post period.

`panelA_dismantling_map_count_based.csv` is the count-based robustness version of Panel A.

`panelB_flag_switching_owner_country_full.csv` contains pre/post owner–final-flag mismatch rates by beneficial-owner country. The top-10 file is the plotting subset.

`panelC_ITF_FoC_final_flag_full.csv` contains pre/post shares by final flag within vessels using an ITF flag of convenience. The top-10 file is the plotting subset.

`summary_key_movers.csv` contains the entities selected for the draft figure. `methodology_notes.csv` records definitions and cautions.

## Figure 3

`figure3_governance_map.xlsx` contains one row per flag jurisdiction, aggregate ship counts and GT, map coordinates, HKC and EU status classifications, summary statistics, and a field dictionary. It contains no individual vessel record. `coord_source` describes geocoding provenance rather than vessel provenance.

## Discussion figure

`responsibility_triangle_values.csv` contains three region-level observations and the LDT-weighted shares used in the responsibility-allocation visualization.

## Source and disclosure classification

Figure 2 and the discussion table are aggregates derived from standardized NGO Shipbreaking Platform annual lists. Figure 1 and the fleet-size component of Figure 3 are derived from an authorized active-fleet register and require licence review before public redistribution. The source records themselves are not included anywhere in this package.
