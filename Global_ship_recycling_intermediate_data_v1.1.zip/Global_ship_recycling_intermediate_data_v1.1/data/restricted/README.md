# Restricted data not included

The repository does not contain the Clarksons active-fleet roster, annual vessel-level dismantling source files, or the standardized vessel-level analysis dataset. Authorized users must obtain those sources independently under the applicable terms.

Do not place restricted inputs inside this repository. The helper script in `code/02_prepare_restricted_fleet_aggregates.py` should be run with an input path outside the public repository and an output path reviewed before publication.
