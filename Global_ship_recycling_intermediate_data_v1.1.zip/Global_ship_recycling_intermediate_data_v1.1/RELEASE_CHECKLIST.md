# Release checklist

## Data boundary

- [x] No annual source ship-list workbook is included.
- [x] No vessel-level processed dataset is included.
- [x] No Clarksons active-fleet roster or market-series workbook is included.
- [x] Included tables are aggregated by year, country, flag jurisdiction, or manuscript category.
- [x] The automated validation script checks for direct-identifier columns and unexpected large tables.

## Required before public release

- [ ] Insert the already reserved DOI in `CITATION.cff` and `ZENODO_METADATA.md`.
- [ ] Insert the final GitHub repository URL in `CITATION.cff`.
- [x] Set the creator name to `Unknown` as requested for this release.
- [ ] Confirm permission to redistribute the derived Figure 1 and Figure 3 aggregates.
- [ ] If that permission is not confirmed, remove both workbooks and update the inventory, manifest, README, and Zenodo description.
- [ ] Add the exact access dates or versions for the ITF and EU classification lists.
- [ ] Run `python code/01_validate_intermediate_release.py` and resolve every failure.
- [ ] Confirm that `MANIFEST.csv` matches the final upload folder.
- [ ] Publish this as a new version of the existing GitHub/Zenodo record, for example `v1.1.0`.
