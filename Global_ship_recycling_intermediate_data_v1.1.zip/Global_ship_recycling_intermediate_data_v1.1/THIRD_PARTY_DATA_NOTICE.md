# Third-party data notice

## NGO Shipbreaking Platform

The Figure 2 and discussion tables are author-created aggregates derived from annual lists of ships dismantled worldwide published by the NGO Shipbreaking Platform. The annual source workbooks and vessel-level standardized records are not included. Users should cite the source landing page: https://shipbreakingplatform.org/annual-lists/

## Clarksons Research

The active-fleet register used for retirement-pressure and flag-state fleet calculations was obtained from the Shipping Intelligence Network of Clarksons Research under licence. No vessel-level Clarksons record or proprietary market series is included.

The Figure 1 and Figure 3 workbooks contain aggregated derived values. Aggregation reduces disclosure risk but does not by itself grant redistribution rights. Before a public GitHub or Zenodo release, the authors must confirm that the applicable licence permits publication of these derived aggregates. If permission is not confirmed, remove those two workbooks and update `DATA_INVENTORY.csv`, `MANIFEST.csv`, `README.md`, and the Zenodo description.

## Institutional classifications

HKC status, the ITF flag-of-convenience list, and the European List of ship-recycling facilities are frozen to the manuscript version. Users should consult and cite the authoritative sources for current classifications. These classifications should not be silently updated within an archived release.
