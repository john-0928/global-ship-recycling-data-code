#!/usr/bin/env python3
"""Validate the aggregate-only intermediate-data release."""

from __future__ import annotations

import csv
import hashlib
from pathlib import Path
import sys

import pandas as pd


ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data" / "intermediate"
EXPECTED = {
    "figure1/figure1_retirement_pressure.xlsx",
    "figure2/methodology_notes.csv",
    "figure2/panelA_dismantling_map_count_based.csv",
    "figure2/panelA_dismantling_map_LDT_weighted.csv",
    "figure2/panelB_flag_switching_owner_country_full.csv",
    "figure2/panelB_flag_switching_owner_country_plot_top10.csv",
    "figure2/panelC_ITF_FoC_final_flag_full.csv",
    "figure2/panelC_ITF_FoC_final_flag_plot_top10.csv",
    "figure2/summary_key_movers.csv",
    "figure3/figure3_governance_map.xlsx",
    "discussion/responsibility_triangle_values.csv",
}
DIRECT_IDENTIFIERS = {
    "imo", "imo_number", "ship_name", "vessel_name", "mmsi",
    "call_sign", "callsign", "official_number",
}


def require(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def check_columns(columns, label: str) -> None:
    normalized = {str(column).strip().lower() for column in columns}
    found = sorted(normalized & DIRECT_IDENTIFIERS)
    require(not found, f"Direct identifier columns in {label}: {found}")


def check_data_files() -> None:
    actual = {
        path.relative_to(DATA).as_posix()
        for path in DATA.rglob("*")
        if path.is_file()
    }
    require(actual == EXPECTED, f"Unexpected data file set. Missing={sorted(EXPECTED-actual)} Extra={sorted(actual-EXPECTED)}")

    for relative in sorted(EXPECTED):
        path = DATA / relative
        if path.suffix.lower() == ".csv":
            frame = pd.read_csv(path)
            check_columns(frame.columns, relative)
            require(len(frame) <= 250, f"Unexpectedly detailed table: {relative} has {len(frame)} rows")
        else:
            workbook = pd.ExcelFile(path)
            for sheet in workbook.sheet_names:
                frame = pd.read_excel(path, sheet_name=sheet)
                check_columns(frame.columns, f"{relative}:{sheet}")
                require(len(frame) <= 250, f"Unexpectedly detailed sheet: {relative}:{sheet} has {len(frame)} rows")


def check_manifest() -> None:
    manifest = ROOT / "MANIFEST.csv"
    require(manifest.exists(), "MANIFEST.csv is missing")
    with manifest.open(encoding="utf-8-sig", newline="") as stream:
        rows = list(csv.DictReader(stream))
    listed = {row["path"]: row for row in rows}
    for relative, row in listed.items():
        path = ROOT / Path(relative)
        require(path.exists(), f"Manifest path missing: {relative}")
        require(sha256(path) == row["sha256"], f"Checksum mismatch: {relative}")
        require(path.stat().st_size == int(row["size_bytes"]), f"Size mismatch: {relative}")


def main() -> None:
    check_data_files()
    check_manifest()
    print(f"PASS: {len(EXPECTED)} aggregate intermediate-data files validated")
    print("PASS: no direct vessel-identifier columns detected")


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        print(f"FAIL: {exc}", file=sys.stderr)
        raise
